package ss;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Observable;
import java.util.Observer;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

/**
 * 
 * @author datanasov
 *
 */
@SuppressWarnings("serial")
public class StempelSystemView extends JFrame implements Observer {

	private JTextField idFeld;// textfeld f�r Mitarbeiter id
	private JTextPane log;// textfeld f�r log
	private JButton start;// button zum einstempeln
	private JButton stop;// button zum ausstempeln

	/**
	 * Create the frame.
	 */
	public StempelSystemView() {// construktor
		setBounds(100, 100, 450, 400);// grosse und position des fenster
		setResizable(false);// darf nicht vergrossert werden
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// operation zum schliessen des frames
		getContentPane().setLayout(null);// kein layout

		idFeld = new JTextField();// textfeld referenziern
		idFeld.setText("Mitarbeiter ID eingeben");// txt set
		idFeld.setHorizontalAlignment(SwingConstants.CENTER);// horizontale center position
		idFeld.setBounds(10, 11, 424, 43);
		idFeld.setBorder(new LineBorder(Color.black, 1, true));// setze einen runden rand it 1px dicke
		idFeld.addMouseListener(new MouseListener() { //

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				idFeld.setText(null);// beim klick verschwindet der default text

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		});
		getContentPane().add(idFeld);
		idFeld.setColumns(10);

		start = new JButton("Start");
		start.setBackground(Color.BLACK);
		start.setForeground(Color.RED);
		start.setBorder(new LineBorder(Color.black, 1, true));
		start.setBounds(10, 65, 80, 80);
		getContentPane().add(start);

		stop = new JButton("Stop");
		stop.setBackground(Color.LIGHT_GRAY);
		stop.setForeground(Color.GREEN);
		stop.setBorder(new LineBorder(Color.black, 1, true));
		stop.setBounds(354, 65, 80, 80);
		getContentPane().add(stop);

		log = new JTextPane();
		log.setBorder(new LineBorder(Color.black, 1, true));
		log.setText("Log...");
		log.setBounds(10, 266, 424, 95);
		log.setBorder(new LineBorder(Color.black, 1, true));
		getContentPane().add(log);

		DigitalUhr uhr = new DigitalUhr();// Mein DigitalUhr erstellen

		uhr.setBorder(null);
		uhr.setBounds(100, 65, 244, 80);

		new Thread(uhr).start();// starte den uhr

		getContentPane().add(uhr);// uhr hinzuf�gen

		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBorder(BorderFactory.createLineBorder(Color.red));
		ImageIcon a = new ImageIcon("C:\\\\Users\\\\datanasov\\\\Desktop\\\\button.jpg");   // Windows path
	//	ImageIcon a = new ImageIcon(getClass().getResource("./button.jpg"));	//Unix Path
		lblNewLabel.setIcon(a);

		
		System.err.println(a);
		System.err.println(a.getIconHeight() + " " + a.getIconWidth());
		lblNewLabel.setBounds(100, 156, 250, 30);
		getContentPane().add(lblNewLabel);

	}

	/**
	 * �berschreibe update methode in der interface observable Es wird ausgef�rt
	 * wenn die methode notifiObserver von der klassse Observable aufgerufen wird
	 */
	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub

	}
}
