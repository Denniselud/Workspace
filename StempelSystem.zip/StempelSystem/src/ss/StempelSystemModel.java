package ss;

import java.util.Map;
import java.util.Observable;
import java.util.TreeMap;

public class StempelSystemModel extends Observable {

	private Map<Integer, Mitarbeiter> alleMitarbeiter;

	public StempelSystemModel() {
		alleMitarbeiter = new TreeMap<Integer, Mitarbeiter>();

	}

	/**
	 * 
	 * @param mitarbeiterID
	 * @param m             kia<ughefliughdu
	 */
	public void mitarbeiterHinzufugen(int mitarbeiterID, Mitarbeiter m) { // lbjdfztzdutr
		alleMitarbeiter.put(mitarbeiterID, m);

	}

	public Mitarbeiter arbeiterSuchen(int id) {
		return alleMitarbeiter.get(id);
	}

	public boolean eingelogt(int mitarbeiterID) {
		
		
		setChanged();
		notifyObservers();
		
		
		
		if (alleMitarbeiter.containsKey(mitarbeiterID)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean einloggen(int mitarbeiterID) {

		if (!eingelogt(mitarbeiterID)) {
			// alleMitarbeiter.put(key, value);
		}

		return false;
	}

	public boolean ausloggen(Mitarbeiter m) {

		return false;
	}

}
