package ss;

import java.awt.EventQueue;
/**
 * Start Klasse
 * @author datanasov
 *
 */
public class StempelSystemMain {

		/**
		 * Hier beginnt und endet alles
		 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {// Neuer Thread Starten
			
			@SuppressWarnings("unused")
			@Override
			public void run() {
				StempelSystemView ssv = new StempelSystemView();//	Frame erstellen
				ssv.setVisible(true);//sichtbar machen
				
				
				StempelSystemModel ssm = new StempelSystemModel();//model erstellen
			}
		});
		
		
		
		
		

	}

}
