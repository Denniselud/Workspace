package ss;

import java.awt.Font;
import java.util.Date;
import javax.swing.JLabel;
import javax.swing.JPanel;
/**
 * Digital Uhr klasse schreibt die uhrzeit in einen jLabel und implementiert Runnable nud Jpanel....
 * @author datanasov
 *
 */
public class DigitalUhr extends JPanel implements Runnable {

	private static final long serialVersionUID = 1L;

	private JLabel uhrLabel;//hier schreiben wir die zeit
	private Date date;//Date objekt wird f�r zeitstempel gebraucht

	public DigitalUhr() {//Construktor

		uhrLabel = new JLabel();//Label erstellen
		this.add(uhrLabel);//Jlabel hinzuf�gen
		System.out.println("uhr erstellen");

	}

	@SuppressWarnings("deprecation")
	@Override
	public void run() {//
		//System.out.println("Uhr Start");
		while (true) {//eine endlose schleife f�r die zeit

			try {
				Font f = new Font(Font.SERIF, Font.PLAIN, 50);//Schrift style und grosse erstellen
				date = new Date();// Date objekt erstellen
				int h = date.getHours();//stunden
				int m = date.getMinutes();//minuten
				int s = date.getSeconds();//sekunden

				String hs = "", ms = "", ss = "";//als string formatieren um (01 statt 1) als ausgabe zur bekommen

				if (h <= 9) {
					hs = "0" + String.valueOf(h);
				} else {
					hs = String.valueOf(h);
				}

				if (m <= 9) {
					ms = "0" + String.valueOf(m);
				} else {
					ms = String.valueOf(m);
				}

				if (s <= 9) {
					ss = "0" + String.valueOf(s);
				} else {
					ss = String.valueOf(s);
				}

				uhrLabel.setFont(f);//Schrift grosse und style setzen
				uhrLabel.setText(hs + ":" + ms + ":" + ss);//UhrzeitString im jlabel setzen
				//System.out.println(hs + ":" + ms + ":" + ss);
				Thread.sleep(1000);//schlafe eine sekunde lang....
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}

	}

}
