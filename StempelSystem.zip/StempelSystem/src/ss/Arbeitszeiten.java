package ss;

import java.util.Date;

public class Arbeitszeiten {

	private Date start;
	

	public Date getStart() {
		return start;
	}

	public void setStart(Date start) {
		this.start = start;
	}

	public Date getStop() {
		return stop;
	}

	public void setStop(Date stop) {
		this.stop = stop;
	}

	private Date stop;

	public Arbeitszeiten() {
		// TODO Auto-generated constructor stub
	}

	public void starteArbeitszeit() {
		start = new Date();
	}

	public void stopeArbeitszeit() {
		stop = new Date();
	}

}
