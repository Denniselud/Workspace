package ss;

import java.util.ArrayList;

/**
 * Klasse Mitarbeiter
 * 
 * @author datanasov
 *
 */
public class Mitarbeiter {
/**
 * 
 */
	private String name;// Mitarbeiter name
	private int id;// Mitarbeiter id
	private ArrayList<Arbeitszeiten> arbeitsstunden;//Datenstruktur f�r die Arbeitszeit
/**
 * Mitarbeiter mit name und id erstellen
 * @param name
 * @param id
 */
	public Mitarbeiter(String name, int id) {
		super();
		this.name = name;
		this.id = id;

	}
/**
 * 
 * @return String
 */
	public String getName() {
		return name;
	}
/**
 * 
 * @param String name
 */
	public void setName(String name) {
		this.name = name;
	}
/**
 * 
 * @return int
 */
	public int getId() {
		return id;
	}
/**
 * 
 * @param int id
 */
	public void setId(int id) {
		this.id = id;
	}
/**
 * 
 * @return Arraylist
 */
	public ArrayList<Arbeitszeiten> getArbeitsstunden() {
		return arbeitsstunden;
	}
/**
 * 
 * @param arbeitsstunden
 */
	public void setArbeitsstunden(ArrayList<Arbeitszeiten> arbeitsstunden) {
		this.arbeitsstunden = arbeitsstunden;
	}

}
